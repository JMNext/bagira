// import Vue from 'vue';

const $ = require("jquery");
const jQuery = $;
window.jQuery = window.$ = jQuery;

// require('owl.carousel');
// require('../js/popper.min.js');
// require('../js/bootstrap.min.js');
// require('@fancyapps/fancybox');
// require('lightgallery');
// require('bootstrap');
// import { Alert, Button, Carousel, Collapse, Dropdown, Tab, Modal, Popover, ScrollSpy, Toast, Tooltip } from 'bootstrap';
// import { Modal } from 'bootstrap';
// import Bootstrap from 'Bootstrap';
// console.log(Bootstrap);
// console.log(Tooltip);

$(document).ready(function () {

});
